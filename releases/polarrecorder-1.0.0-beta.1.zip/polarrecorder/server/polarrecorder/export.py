"""Module: Export - Polar projection, CSV export, and preset persistence.

Documentation: documentation/user/export-import.md
Depends: polarrecorder.bins, polarrecorder.histogram
"""

from __future__ import annotations

import json
import os
import re
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING, cast

from polarrecorder import histogram
from polarrecorder.bins import TWS_BIN_MAX

if TYPE_CHECKING:
    from polarrecorder.logger import Logger

MIN_SAMPLES_DISPLAY = 3
PERCENTILE_MIN = 1
PERCENTILE_MAX = 99
PRESET_NAME_MAX_LENGTH = 30
PRESET_SCHEMA_VERSION = 1
PRESETS_NAME = "presets.json"
PRESETS_TMP_NAME = "presets.tmp.json"
WINDY_NAME = "windy"
TWA_FOLD_MAX = 180
TWA_FULL_CIRCLE = 360
WINDY_TWA = [0, 30, 40, 52, 60, 75, 90, 110, 120, 135, 150, 165, 180]
WINDY_TWS = [4, 6, 8, 10, 12, 14, 16, 20, 25]
NAME_PATTERN = re.compile(r"^[A-Za-z0-9 -]+$")


class ExportError(ValueError):
    """Raised when export or preset parameters are invalid."""


@dataclass(frozen=True)
class Preset:
    """Resolved export preset."""

    name: str
    builtin: bool
    twa: list[int]
    tws: list[int]


@dataclass(frozen=True)
class ProjectedCell:
    """One projected polar grid cell."""

    stw: float
    samples: int


@dataclass(frozen=True)
class ExportSelection:
    """Resolved export grid and confidence floor."""

    name: str
    twa: list[int]
    tws: list[int]
    min_samples: int


SnapshotBins = Mapping[tuple[int, int], Mapping[str, object]]


def builtin_preset() -> Preset:
    """Return the hardcoded Windy Passage Planner preset."""
    return Preset(WINDY_NAME, builtin=True, twa=list(WINDY_TWA), tws=list(WINDY_TWS))


def list_presets(data_dir: str | os.PathLike[str], logger: Logger | None = None) -> list[Preset]:
    """Return Windy plus user presets from disk."""
    presets = [builtin_preset()]
    for name, preset in sorted(_load_user_presets(data_dir, logger).items()):
        presets.append(Preset(name, builtin=False, twa=list(preset.twa), tws=list(preset.tws)))
    return presets


def save_preset(
    data_dir: str | os.PathLike[str],
    name: str,
    twa_text: str,
    tws_text: str,
    max_tws: int,
    logger: Logger | None = None,
) -> Preset:
    """Create or overwrite a user preset."""
    preset = Preset(
        name=_validate_name(name),
        builtin=False,
        twa=_parse_grid("twa", twa_text, 0, TWA_FOLD_MAX),
        tws=_parse_grid("tws", tws_text, 1, max_tws),
    )
    presets = _load_user_presets(data_dir, logger)
    presets[preset.name] = preset
    _write_user_presets(data_dir, presets, logger)
    return preset


def delete_preset(
    data_dir: str | os.PathLike[str],
    name: str,
    confirm: str,
    logger: Logger | None = None,
) -> None:
    """Delete a user preset after confirmation."""
    if confirm != "yes":
        msg = "Invalid parameter 'confirm': expected 'yes'"
        raise ExportError(msg)
    trimmed = name.strip()
    if trimmed.lower() == WINDY_NAME:
        msg = "Preset 'windy' is built in and cannot be deleted"
        raise ExportError(msg)
    presets = _load_user_presets(data_dir, logger)
    if trimmed not in presets:
        msg = f"Unknown preset '{trimmed}'"
        raise ExportError(msg)
    del presets[trimmed]
    _write_user_presets(data_dir, presets, logger)


def resolve_polar_preset(
    data_dir: str | os.PathLike[str],
    args: Mapping[str, str],
    logger: Logger | None = None,
) -> Preset:
    """Resolve the named preset used by the polar diagram."""
    name = args.get("format", WINDY_NAME)
    if name.lower() == WINDY_NAME:
        return builtin_preset()
    user = _load_user_presets(data_dir, logger).get(name)
    if user is None:
        msg = f"Unknown format '{name}'"
        raise ExportError(msg)
    return user


def resolve_export_selection(
    data_dir: str | os.PathLike[str],
    args: Mapping[str, str],
    max_tws: int,
    min_samples_for_export: int,
    logger: Logger | None = None,
) -> ExportSelection:
    """Resolve CSV export mode, grid, and confidence floor."""
    min_samples = _resolve_min_samples(args, min_samples_for_export)
    has_twa = "twa" in args
    has_tws = "tws" in args
    if "format" in args and (has_twa or has_tws):
        msg = "Invalid parameters: 'format' cannot be combined with 'twa' or 'tws'"
        raise ExportError(msg)
    if has_twa != has_tws:
        msg = "Invalid parameters: 'twa' and 'tws' must be supplied together"
        raise ExportError(msg)
    if has_twa and has_tws:
        return ExportSelection(
            "custom",
            _parse_grid("twa", args["twa"], 0, TWA_FOLD_MAX),
            _parse_grid("tws", args["tws"], 1, max_tws),
            min_samples,
        )
    preset = resolve_polar_preset(data_dir, args, logger)
    return ExportSelection(preset.name, list(preset.twa), list(preset.tws), min_samples)


def parse_percentile(args: Mapping[str, str], default: int) -> int:
    """Parse an optional percentile query parameter."""
    raw = args.get("percentile")
    if raw is None:
        return default
    try:
        value = int(raw)
    except ValueError as exc:
        msg = f"Invalid parameter 'percentile': expected integer 1-99, got {raw!r}"
        raise ExportError(msg) from exc
    if PERCENTILE_MIN <= value <= PERCENTILE_MAX:
        return value
    msg = f"Invalid parameter 'percentile': expected integer 1-99, got {raw!r}"
    raise ExportError(msg)


def project_grid(
    model_bins: SnapshotBins,
    twa_grid: Sequence[int],
    tws_grid: Sequence[int],
    percentile: int,
    min_samples: int,
) -> dict[tuple[int, int], ProjectedCell]:
    """Project sparse raw bins onto a target TWA/TWS grid."""
    projected: dict[tuple[int, int], ProjectedCell] = {}
    folded = _folded_bins(model_bins)
    twa_intervals = _intervals(twa_grid, TWA_FOLD_MAX)
    tws_intervals = _intervals(tws_grid, TWS_BIN_MAX)
    for twa, twa_lower, twa_upper, twa_last in twa_intervals:
        for tws, tws_lower, tws_upper, tws_last in tws_intervals:
            merged = _cell_histogram(
                folded,
                (twa_lower, twa_upper, twa_last),
                (tws_lower, tws_upper, tws_last),
            )
            samples = sum(merged.values())
            speed = histogram.percentile(merged, percentile)
            if samples >= min_samples and speed is not None:
                projected[(twa, tws)] = ProjectedCell(stw=speed, samples=samples)
    return projected


def csv_from_projection(
    projected: Mapping[tuple[int, int], ProjectedCell],
    twa_grid: Sequence[int],
    tws_grid: Sequence[int],
) -> str:
    """Format projected cells as Windy-compatible semicolon CSV."""
    rows = ["TWA\\TWS;" + ";".join(str(tws) for tws in tws_grid)]
    for twa in twa_grid:
        values = [str(twa)]
        for tws in tws_grid:
            cell = projected.get((twa, tws))
            values.append("" if cell is None else f"{cell.stw:.1f}")
        rows.append(";".join(values))
    return "\r\n".join(rows) + "\r\n"


def csv_export(
    model_bins: SnapshotBins,
    selection: ExportSelection,
    percentile: int,
) -> str:
    """Project model bins and return CSV text."""
    projected = project_grid(
        model_bins,
        selection.twa,
        selection.tws,
        percentile,
        selection.min_samples,
    )
    return csv_from_projection(projected, selection.twa, selection.tws)


def _resolve_min_samples(args: Mapping[str, str], min_samples_for_export: int) -> int:
    if args.get("high_confidence", "").lower() in {"yes", "true", "1"}:
        return min_samples_for_export
    return MIN_SAMPLES_DISPLAY


def _validate_name(name: str) -> str:
    trimmed = name.strip()
    if trimmed.lower() == WINDY_NAME:
        msg = "Preset name 'windy' is reserved"
        raise ExportError(msg)
    if not 1 <= len(trimmed) <= PRESET_NAME_MAX_LENGTH or NAME_PATTERN.fullmatch(trimmed) is None:
        msg = "Invalid parameter 'name': expected 1-30 alphanumeric, hyphen, or space chars"
        raise ExportError(msg)
    return trimmed


def _parse_grid(name: str, raw: str, lower: int, upper: int) -> list[int]:
    values: list[int] = []
    for part in raw.split(","):
        text = part.strip()
        if not text:
            continue
        try:
            value = int(text)
        except ValueError as exc:
            msg = f"Invalid parameter '{name}': expected comma-separated integers"
            raise ExportError(msg) from exc
        if not lower <= value <= upper:
            msg = f"Invalid parameter '{name}': expected values {lower}-{upper}"
            raise ExportError(msg)
        values.append(value)
    if not values:
        msg = f"Invalid parameter '{name}': expected at least one value"
        raise ExportError(msg)
    return sorted(set(values))


def _load_user_presets(
    data_dir: str | os.PathLike[str],
    logger: Logger | None,
) -> dict[str, Preset]:
    path = Path(data_dir) / PRESETS_NAME
    if not path.exists():
        _log_warn(logger, "presets.json is missing; using built-in presets only")
        return {}
    try:
        decoded = json.loads(path.read_text(encoding="utf-8"))
        data = cast("dict[str, object]", decoded)
        if _to_int(data.get("schema_version", 0)) > PRESET_SCHEMA_VERSION:
            _log_warn(logger, "presets.json schema is too new; discarding user presets")
            return {}
        raw_presets = data.get("presets", {})
        return _decode_presets(_require_presets_dict(raw_presets))
    except (OSError, json.JSONDecodeError, TypeError, ValueError) as exc:
        _log_warn(logger, f"presets.json is corrupt; using built-in presets only: {exc}")
        return {}


def _decode_presets(raw_presets: dict[object, object]) -> dict[str, Preset]:
    presets: dict[str, Preset] = {}
    for raw_name, raw_preset in raw_presets.items():
        if not isinstance(raw_preset, dict):
            continue
        name = str(raw_name)
        twa = _int_list(raw_preset.get("twa", []))
        tws = _int_list(raw_preset.get("tws", []))
        if twa and tws and name.lower() != WINDY_NAME:
            presets[name] = Preset(name, builtin=False, twa=sorted(twa), tws=sorted(tws))
    return presets


def _require_presets_dict(raw_presets: object) -> dict[object, object]:
    if isinstance(raw_presets, dict):
        return raw_presets
    msg = "presets block is not an object"
    raise TypeError(msg)


def _write_user_presets(
    data_dir: str | os.PathLike[str],
    presets: Mapping[str, Preset],
    logger: Logger | None,
) -> None:
    root = Path(data_dir)
    path = root / PRESETS_NAME
    tmp = root / PRESETS_TMP_NAME
    payload = {
        "schema_version": PRESET_SCHEMA_VERSION,
        "presets": {
            name: {"twa": list(preset.twa), "tws": list(preset.tws)}
            for name, preset in sorted(presets.items())
        },
    }
    text = json.dumps(payload, sort_keys=True, separators=(",", ":"))
    try:
        root.mkdir(parents=True, exist_ok=True)
        with tmp.open("w", encoding="utf-8") as handle:
            handle.write(text)
            handle.flush()
            os.fsync(handle.fileno())
        tmp.replace(path)
    except OSError as exc:
        _cleanup_tmp(tmp, logger)
        msg = f"Failed to save presets.json: {exc}"
        raise ExportError(msg) from exc


def _folded_bins(model_bins: SnapshotBins) -> list[tuple[int, int, Mapping[int, int]]]:
    folded: list[tuple[int, int, Mapping[int, int]]] = []
    for (twa, tws), data in sorted(model_bins.items()):
        raw_histogram = data.get("histogram", {})
        if isinstance(raw_histogram, dict):
            folded_twa = twa if twa <= TWA_FOLD_MAX else TWA_FULL_CIRCLE - twa
            folded.append((folded_twa, tws, _int_histogram(raw_histogram)))
    return folded


def _cell_histogram(
    folded: Sequence[tuple[int, int, Mapping[int, int]]],
    twa_interval: tuple[float, float, bool],
    tws_interval: tuple[float, float, bool],
) -> dict[int, int]:
    merged: dict[int, int] = {}
    for twa, tws, source in folded:
        if _inside(twa, twa_interval) and _inside(tws, tws_interval):
            for key, count in source.items():
                merged[key] = merged.get(key, 0) + count
    return merged


def _intervals(values: Sequence[int], upper_axis: int) -> list[tuple[int, float, float, bool]]:
    return [
        (
            value,
            0.0 if index == 0 else (values[index - 1] + value) / 2.0,
            float(upper_axis) if index == len(values) - 1 else (value + values[index + 1]) / 2.0,
            index == len(values) - 1,
        )
        for index, value in enumerate(values)
    ]


def _inside(value: int, interval: tuple[float, float, bool]) -> bool:
    lower, upper, closed_upper = interval
    if closed_upper:
        return lower <= value <= upper
    return lower <= value < upper


def _int_histogram(raw: dict[object, object]) -> dict[int, int]:
    return {_to_int(key): _to_int(count) for key, count in raw.items()}


def _int_list(raw: object) -> list[int]:
    if not isinstance(raw, list):
        return []
    return [_to_int(item) for item in raw]


def _to_int(value: object) -> int:
    if isinstance(value, (str, bytes, bytearray, int, float)):
        return int(value)
    msg = f"Expected int-compatible value, got {type(value).__name__}"
    raise TypeError(msg)


def _cleanup_tmp(path: Path, logger: Logger | None) -> None:
    try:
        path.unlink(missing_ok=True)
    except OSError as exc:
        _log_warn(logger, f"Could not remove presets temp file: {exc}")


def _log_warn(logger: Logger | None, message: str) -> None:
    if logger is not None:
        logger.warning(message)
