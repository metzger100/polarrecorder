"""Module: Enhanced Validation Rules - Optional-signal rejection rules.

Documentation: documentation/filters/rejection-rules.md
Depends: polarrecorder.config, polarrecorder.sample, polarrecorder.validation.angle_math
"""

from __future__ import annotations

import math
from typing import TYPE_CHECKING

from polarrecorder.sample import RuleResult, enhanced_value, pass_rule, reject_rule
from polarrecorder.validation.angle_math import circular_distance

if TYPE_CHECKING:
    from polarrecorder.config import Config
    from polarrecorder.sample import Sample

_FULL_CIRCLE_DEG = 360.0


def reject_engine_rpm(sample: Sample, config: Config) -> RuleResult:
    """Reject (R17) when engine RPM exceeds the configured idle ceiling."""
    rpm = enhanced_value(sample, "rpm")
    if rpm is not None and rpm > config.enh_rpm_idle_max:
        return _reject("reject_engine_rpm")
    return _pass()


def reject_shallow(sample: Sample, config: Config) -> RuleResult:
    """Reject (R19) when depth/keel clearance is below the configured floor."""
    depth_m = enhanced_value(sample, "depth_m")
    if depth_m is not None and depth_m < config.enh_depth_floor_m:
        return _reject("reject_shallow")
    return _pass()


def reject_sog_stw_mismatch(sample: Sample, config: Config) -> RuleResult:
    """Reject (R20) when SOG and STW disagree beyond explainable current drift."""
    sog_kt = enhanced_value(sample, "sog_kt")
    current_drift_kt = enhanced_value(sample, "current_drift_kt")
    if sog_kt is None:
        return _pass()
    current_is_invalid = "current_drift_kt" in sample.invalid_enhanced_roles
    if current_drift_kt is None and not current_is_invalid:
        return _pass()
    faster = max(sog_kt, sample.stw_kt)
    slower = min(sog_kt, sample.stw_kt)
    gap = faster - slower
    moving = faster > config.enh_slip_sog_floor_kt
    ratio_mismatch = slower < faster * config.enh_slip_ratio
    current_too_small = current_drift_kt is None or current_drift_kt < gap
    if moving and ratio_mismatch and current_too_small:
        return _reject("reject_sog_stw_mismatch")
    return _pass()


def reject_true_wind_crosscheck(sample: Sample, config: Config) -> RuleResult:
    """Reject (R21) when true wind recomputed from apparent wind disagrees with reports."""
    awa_deg = enhanced_value(sample, "awa_deg")
    aws_kt = enhanced_value(sample, "aws_kt")
    if awa_deg is None or aws_kt is None:
        return _pass()
    awa_rad = math.radians(awa_deg)
    stw = sample.stw_kt
    x = aws_kt * math.cos(awa_rad) - stw
    y = aws_kt * math.sin(awa_rad)
    tws_calc = math.hypot(x, y)
    twa_calc = math.degrees(math.atan2(y, x)) % _FULL_CIRCLE_DEG
    twa_off = circular_distance(twa_calc, sample.twa_deg_raw) > config.enh_tw_twa_tol_deg
    tws_off = abs(tws_calc - sample.tws_kt) > config.enh_tw_tws_tol_kt
    if twa_off or tws_off:
        return _reject("reject_true_wind_crosscheck")
    return _pass()


def reject_heel_out_of_band(sample: Sample, config: Config) -> RuleResult:
    """Reject (R22) when absolute heel is outside the configured [min, max] band."""
    heel_deg = enhanced_value(sample, "heel_deg")
    if heel_deg is None:
        return _pass()
    heel_abs = abs(heel_deg)
    if heel_abs > config.enh_heel_max_deg or heel_abs < config.enh_heel_min_deg:
        return _reject("reject_heel_out_of_band")
    return _pass()


_pass = pass_rule
_reject = reject_rule
