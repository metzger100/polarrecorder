"""Module: Core Validation Rules - Candidacy-gate checks R1 through R10.

Documentation: documentation/filters/rejection-rules.md
Depends: polarrecorder.config, polarrecorder.enhanced_input, polarrecorder.sample,
polarrecorder.units
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from polarrecorder.enhanced_input import classify_timestamp_age, coerce_finite_timestamp
from polarrecorder.sample import (
    RuleResult,
    enhanced_value,
    is_finite_core_value,
    pass_rule,
    reject_rule,
)
from polarrecorder.units import is_finite_meters_per_second_input

if TYPE_CHECKING:
    from polarrecorder.config import Config
    from polarrecorder.sample import ReadResult, Sample

TWA_MIN_DEGREES = 0.0
TWA_MAX_DEGREES = 360.0


def finite_values(read_result: ReadResult) -> RuleResult:
    """Reject non-numeric or non-finite raw values.

    Args:
        read_result: Raw store read.

    Returns:
        Pass or reject with one code per non-finite value.
    """
    codes: list[str] = []
    _add_non_finite_code(codes, read_result.twa_raw, "reject_non_finite_twa")
    _add_non_finite_speed_code(codes, read_result.tws_raw, "reject_non_finite_tws")
    _add_non_finite_speed_code(codes, read_result.stw_raw, "reject_non_finite_stw")
    _add_invalid_timestamp_code(codes, read_result.twa_timestamp, "reject_non_finite_twa")
    _add_invalid_timestamp_code(codes, read_result.tws_timestamp, "reject_non_finite_tws")
    _add_invalid_timestamp_code(codes, read_result.stw_timestamp, "reject_non_finite_stw")
    return _multi_result(codes)


def required_keys(read_result: ReadResult) -> RuleResult:
    """Reject missing required raw values.

    Args:
        read_result: Raw store read.

    Returns:
        Pass or reject with one code per missing value.
    """
    codes: list[str] = []
    if read_result.twa_raw is None:
        _append_unique(codes, "reject_missing_twa")
    if read_result.tws_raw is None:
        _append_unique(codes, "reject_missing_tws")
    if read_result.stw_raw is None:
        _append_unique(codes, "reject_missing_stw")
    if read_result.twa_raw is not None and read_result.twa_timestamp is None:
        _append_unique(codes, "reject_missing_twa")
    if read_result.tws_raw is not None and read_result.tws_timestamp is None:
        _append_unique(codes, "reject_missing_tws")
    if read_result.stw_raw is not None and read_result.stw_timestamp is None:
        _append_unique(codes, "reject_missing_stw")
    return _multi_result(codes)


def stale_values(sample: Sample, config: Config) -> RuleResult:
    """Reject stale core values.

    Args:
        sample: Built sample.
        config: Runtime validation thresholds.

    Returns:
        Pass or reject with one code per stale value.
    """
    codes: list[str] = []
    if classify_timestamp_age(sample.freshness.twa_age_s, config.stale_threshold) != "usable":
        codes.append("reject_stale_twa")
    if classify_timestamp_age(sample.freshness.tws_age_s, config.stale_threshold) != "usable":
        codes.append("reject_stale_tws")
    if classify_timestamp_age(sample.freshness.stw_age_s, config.stale_threshold) != "usable":
        codes.append("reject_stale_stw")
    return _multi_result(codes)


def age_skew(sample: Sample, config: Config) -> RuleResult:
    """Reject samples whose core value timestamps are too far apart."""
    if sample.freshness.age_skew_s >= config.age_skew_threshold:
        return _reject("reject_age_skew")
    return _pass()


def twa_range(sample: Sample, config: Config) -> RuleResult:
    """Reject raw TWA outside the 0-360 degree store convention."""
    del config
    if not TWA_MIN_DEGREES <= sample.twa_deg_raw <= TWA_MAX_DEGREES:
        return _reject("reject_twa_range")
    return _pass()


def tws_range(sample: Sample, config: Config) -> RuleResult:
    """Reject implausible true wind speeds."""
    if not 0.0 <= sample.tws_kt <= config.max_tws:
        return _reject("reject_tws_range")
    return _pass()


def stw_range(sample: Sample, config: Config) -> RuleResult:
    """Reject implausible speeds through water."""
    if not 0.0 <= sample.stw_kt <= config.max_stw:
        return _reject("reject_stw_range")
    return _pass()


def head_to_wind(sample: Sample, config: Config) -> RuleResult:
    """Reject samples inside the no-sailing head-to-wind zone."""
    if sample.twa_deg_abs < config.head_to_wind_threshold:
        return _reject("reject_head_to_wind")
    return _pass()


def low_wind(sample: Sample, config: Config) -> RuleResult:
    """Reject very low true wind samples."""
    if sample.tws_kt < config.low_wind_threshold:
        return _reject("reject_low_wind")
    return _pass()


def anchored_heuristic(sample: Sample, config: Config) -> RuleResult:
    """Reject anchored-like samples using SOG when available, else STW."""
    sog_kt = enhanced_value(sample, "sog_kt")
    anchor_speed = sample.stw_kt if sog_kt is None else sog_kt
    if anchor_speed < config.anchored_stw_threshold and sample.tws_kt > 0.0:
        return _reject("reject_anchored")
    return _pass()


def _add_non_finite_code(codes: list[str], value: object | None, code: str) -> None:
    if value is None:
        return
    if not is_finite_core_value(value):
        codes.append(code)


def _add_non_finite_speed_code(codes: list[str], value: object | None, code: str) -> None:
    if value is not None and not is_finite_meters_per_second_input(value):
        codes.append(code)


def _add_invalid_timestamp_code(codes: list[str], value: object | None, code: str) -> None:
    if value is not None and coerce_finite_timestamp(value) is None:
        _append_unique(codes, code)


def _append_unique(codes: list[str], code: str) -> None:
    if code not in codes:
        codes.append(code)


def _multi_result(codes: list[str]) -> RuleResult:
    if codes:
        return RuleResult(decision="reject", reason_codes=tuple(codes))
    return _pass()


_pass = pass_rule
_reject = reject_rule
